---
title: hexo
date: 2019-10-22 15:02:19
tags: 实践
---
# 通过*Hexo*建立个人博客站点 

## 什么是 Hexo？

Hexo 是一个快速、简洁且高效的博客框架。Hexo 使用 [Markdown](http://daringfireball.net/projects/markdown/)（或其他渲染引擎）解析文章，在几秒内，即可利用靓丽的主题生成静态网页。

![](start.png)
<!--more-->
### 安装前提

安装 Hexo 相当简单，只需要先安装下列应用程序即可：

-   [Node.js](http://nodejs.org/) (Node.js 版本需不低于 8.6，建议使用 Node.js 10.0 及以上版本)
-   [Git](http://git-scm.com/)

### 安装步骤

#### 1.git基础安装

```shell
yum -y install git gcc gcc-c++ curl wget
```

为什么要首先要安装 git？

因为 Hexo 开源且基于 Node.js 环境，所以大量主题和设置需要通过 git 完成。 

#### 2.安装 Node.js

```shell
git clone https://github.com/cnpm/nvm.git
cd nvm
sh ./install.sh
source $HOME/nvm/nvm.sh
```

```shell
nvm install v0.10.32 && nvm use 0.10
```

#### 踩坑！！

nodejs版本过低，会导后面的安装步骤报错。

解决办法：升级nodejs，建议使用 **Node.js 10.0 及以上**版本 。

升级nodejs教程如下：

[在centos7安装nodejs并升级nodejs到最新版本](https://segmentfault.com/a/1190000015302680) 

#### 3.部署Hexo

**安装Hexo**

```shell
npm install -g hexo --save
```

**初始化Hexo**

```shell
mkdir /home/wwwroot && hexo init /home/wwwroot
```

#### 4.列举几个常用配置

配置文件_config.yml就在上一步初始化所填写的路径内。

![](config.png)

![](configfile.png)

时区列表可参考该网页：[时区列表](https://en.wikipedia.org/wiki/List_of_tz_database_time_zones)

#### 坑！！注意！！！

在填写配置表时，**’ : ‘** 后面要紧跟一个空格再写具体配置，否则在启动Hexo的时候会报错！

#### 5.启动Hexo

完成上面简单的几部，我们的私人博客已经建好了。下面启动查看。启动后我们可以访问http://localhost:4000/ 查看，发现已经有一篇默认的博客。

```shell
hexo server 或 hexo s
```

![](default_html.png)

**太丑了怎么办！**

![](ugly.jpeg)

**别急，Hexo拥有许多强大特性的,现代、简洁的主题！**

![](thems.png)

我这里找了一个帖子，有楼主收集了很多好看的主题，并附有github下载链接。帖子链接：[Hexo主题](https://www.zhihu.com/question/24422335)

**如何使用主题？**

将主题下载到安装路径下的themes目录里，我这里是 `wwwroot/themes`。

![](wwwroot_themes.png)

下载好主题后需在配置表_config.yml里修改主题。

![](themes_config.png)

**替换后效果：**

![](myblog.png)

### 好了，花里胡哨的东西讲完了，我们的网页还是在本地跑，这可太low了！

如果你有云服务器，你把这一切部署在你的服务器上，别人就可以访问了。但是，如果你**没钱买服务器**，Hexo也为你们考虑到了！

![](nomoney.jpg)

### 我们可以把搭建的Hexo关联Git（GitHub与Gitlab都可以，此处只列举如何关联GitHub）

#### 创建仓库

登录你的Github帐号，新建仓库，命名为**用户名.github.io**固定写法，如scooola.github.io即下图中所示：

![](github.png)用文本编辑器打开_config.yml,打开后往下滑到最后，修改成下边的样子： 

```yaml
deploy: 
    type: git 
    repository: https://github.com/scooola/scooola.github.io.git 
    branch: master
```

在blog文件夹目录下执行生成静态页面命令： 

```shell
$ hexo generate 或者：hexo g
```

此时若出现如下报错： 

```shell
ERROR Local hexo not found in ~/blog
ERROR Try runing: 'npm install hexo --save'

则执行命令：npm install hexo --save
若无报错，自行忽略此步骤。
```

再执行配置命令： 

```shell
$ hexo deploy 或者：hexo d
```

**注意坑**：

若执行命令hexo deploy 仍然报错：无法连接git或找不到git，则执行如下命令来安装**hexo-deployer-git**： 

```shell
$ npm install hexo-deployer-git --save
```

安装完毕后，再次执行hexo generate和hexo deploy命令。 若你未关联Github，则执行hexo deploy 命令时终端会提示你输入Github的用户名和密码，即 

```shell
Username for 'https://github.com':
Password for 'https://github.com':
```

hexo deploy 命令执行成功后，浏览器中打开网址[http://scooola.github.io](http://scooola.github.io)（将scooola换成你的用户名）能看到和打开[http://localhost:4000](http://localhost:4000) 时一样的页面。

### 发布新文章

输入 hexo new 文章名.md，即可在wwwroot/source/_posts目录下看的新生成的文件。

![](new_blog.png)

随后生成静态网页

```shell
hexo generate 或 hexo g
```

发布网站（推送到github）

```shell
hexo deploy 或 hexo d
```

输入完上述命令后，我们就可以在我们的网页上看到新发布的博客了！

#### 可是没有图片的博客也太过于枯燥了，我们需要修改一下配置才可以发布带有图片的博客

下面我们修改配置**post_asset_folder: true**

![](poster_asset_folder.png)

我们再次输入创建博客的命令 hexo new 文件名，发现在source/_posts/目录下创建了一个文件以及同名的文件夹。

![](blog_with_photo.png)

之后，需要安装一个插件，在hexo的安装目录下运行：

```shell
npm install hexo-asset-image --save
```

安装完成后，我们可以把图片放入刚才创建的文件blog-可加入图片内，在md文件中如下格式引入即可：

```
![](图片名.jpg)
```

引入图片后的效果如下图：

![](photo_in_blog.png)

### 关于md文件插入本地图片在GitHub Pages无法显示的问题说明

由于hexo3版本后对很多插件支持有问题，hexo-asset-image插件在处理data.permalink链接时出现路径错误，把年月去掉了，导致最后生成的路径为%d/xxx/xxx需要对其做兼容处理。通过判断当前版本是否等于3的版本做不同的路径分割。因此，这里提供一个已经修复这个bug的插件

```shell
npm install https://github.com/7ym0n/hexo-asset-image --save
```

之后重新编译发布即可。然后刷新浏览器即可！

#### hexo博客迁移

## 备份原文件

需要转移的文件有：

| 文件(夹)     | 说明                 |
| :----------- | :------------------- |
| scaffolds/   | 博客文章模板         |
| source/      | 所有的博客文章       |
| themes/      | 网站主题             |
| .gitignore   | push时需忽略的文件   |
| _config.yml  | 站点配置文件         |
| package.json | 依赖包的名称和版本号 |

由于配置文件和主题文件需要经常更改，采用github创建博客分支的方式进行备份。

## 创建分支

克隆github上上生成的静态文件到hexo文件夹中

```shell
git clone https://github.com/yourname/xxxx.github.io.git hexo
```

克隆后将除.git文件外其他所有文件删除。主要是为了得到版本管理文件夹.git。

**.git文件为隐藏文件，可直接将可见文件全部删除**

将备份的原文件复制到此文件夹。若文件夹是从github克隆，则需要删除主题文件中的版本控制文件夹,以next主题为例：

```shell
$ rm -rf thems/next/.git*
```

创建名为hexo的分支

```shell
$ git checkout -b hexo
```

保存所有文件到暂存区

```shell
$ git add --all
```

提交变更

```shell
$ git commit -m "hexo服务备份"
```

**迁移**

以后在其他电脑上写博客，直接将分支克隆下来。再使用npm install安装依赖。

```shell
$ git clone -b hexo https://github.com/yourname/xxx.github.io.git
$ npm install
```

### hexo生成文章目录-该方法仅支持默认主题

Hexo博客系统的核心支持生成目录（Table of Contents），但其默认的主题Landscape并不支持目录的显示。我们只需对Landscape的主题文件稍作修改并添加一点目录的CSS就可以在文章前面显示友好的目录了。

#### 修改Landscape主题的ejs文件

我们首先要编辑文章显示页面的模板，也就是`themes/landscape/layout/_partial/article.ejs`文件。为了将目录生成在正文之前，我们首先在这个文件中找到`<%- post.content %>`，并在**这一行之前**加入如下代码：

```css
<!-- Table of Contents -->
<% if (!index && post.toc){ %>
  <div id="toc" class="toc-article">
    <strong class="toc-title">文章目录</strong>
    <%- toc(post.content), {list_number: false} %>
  </div>
<% } %>
```

其中list_number:false表示不显示序号，如果你想要打开可以设置为true

修改完这个文件之后，找一篇包含了多个子标题的文章，并在文章开头的front-matter中添加一句`toc: true`，在浏览器中访问这篇文章，应该可以看到文章的开头处已经有了带链接的目录。但是这样的目录实在太难看，我们还需要添加相应的CSS来将其指定为我们想要的样式。

**踩坑**：若目录不能跳转，则可能安装了hexo-toc 这个插件导致的 ，所以卸载掉重新发布就好。

```shell
npm remove hexo-toc --save
```

#### 为目录编写CSS文件

要指定目录的样式，我们要修改的文件是`themes/landscape/source/css/_partial/article.styl`。在文件的最后，添加如下代码：

```css
/*toc*/
.toc-article
  background #eee
  border 1px solid #bbb
  border-radius 10px
  margin 1.5em 0 0.3em 1.5em
  padding 1.2em 1em 0 1em
  max-width 28%
.toc-title
  font-size 120%
#toc
  line-height 1em
  font-size 0.9em
  float right
  .toc
    padding 0
    margin 1em
    line-height 1.8em
    li
      list-style-type none
  .toc-child 
    margin-left 1em
```

第一段的`toc-article`指定了目录整个``的背景色、边框色、倒角半径、各种间距以及最大的宽度。注意这里最好指定目录的最大宽度，我将其设为了`28%`，也就是文章正文那个框的宽度的`28%`，也可以设为一个固定的长度，比如在笔记本电脑上`16em`就是个不错的宽度，但为了能适配各种不同尺寸的屏幕，最好还是设置为百分比。如果不指定最大宽度，遇到比较长的标题时，生成的目录会非常难看。这个最大宽度的设置是我在网上其他添加目录的方法中没有见到的。

第二段的`toc-title`指的就是“文章目录”那四个字，这四个字要比其他字大一些，将其字号设为其他字的`120%`。

第三段的`#toc.toc`指定了目录列表的一些细节，将`font-size`设为`0.9em`会让目录的字比文章的字稍小一些。最后的`.toc-child`指定了二级目录的缩进量。

再次生成页面，应该已经可以显示比较美观的目录了。

#### 收尾工作

通常情况下我们不需要为每一篇文章都添加目录，因为大部分文章的长度还是相对较短，或者结构简单而没有添加小标题。在我的博客上，需要添加目录的长文还是相对较少的。因为我选择了默认不生成目录，而手动为需要目录的文章添加显式地标记。

下面我就需要编辑每一篇需要添加目录的文章，在文章开头的front-matter中加入`toc: true`。
