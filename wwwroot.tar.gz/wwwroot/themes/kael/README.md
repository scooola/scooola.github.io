[中文详细说明点这里](http://yuche.me/introducing-kael-customization/)

↑↑↑↑↑↑↑↑↑↑↑↑↑↑

## WARNING
The code is full of shit.

## Feature

 - Multi Level Push Menu 
 - Archive/Tags/Categoies Instant Search
 - Pjax with Progress Bar
 - Inline Comment just like [Medium](http://medium.com/)
 - Scroll Spy

## Browser Support

 - Internet Explorer 9 +
 - Google Chrome 26 +
 - Firefox 6 +
 - Opera 20 +
 - Safari 5 +

 
## Preview
![kael-preview][1]
 
## Installation

### Install

$ git clone git@github.com:yuche/hexo-theme-kael.git themes/kael

### Enable

Modify theme setting in blog folder `_config.yml` to `kael`.



  [1]: http://ww1.sinaimg.cn/large/650625begw1egigcsgddcg20z60iue81.gif
